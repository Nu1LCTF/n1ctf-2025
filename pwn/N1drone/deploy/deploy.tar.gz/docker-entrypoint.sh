#!/bin/sh

sed -i "s/flag{fake_flag}/$FLAG/" /home/ctf/flag
export FLAG=""

socat TCP-LISTEN:8080,fork,reuseaddr EXEC:./bin/px4
