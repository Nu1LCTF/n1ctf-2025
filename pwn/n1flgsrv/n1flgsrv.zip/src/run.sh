#!/bin/sh
cd "$(dirname "$0")"

echo 'use `kctf-pow solve` to prove yourself :)'

./kctf-pow ask 15000

if [ $? -ne 0 ]; then
	echo 'PoW failed';
	exit;
fi

#{
#  set -e
#  sleep 90
#  kill -9 $$
#} &

timeout -s KILL 90s ./launch_qemu.sh

exit 0
